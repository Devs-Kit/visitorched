<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Visitor Management - CHED</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script>
        tailwind.config = { darkMode: 'class' }
    </script>
</head>
<body class="bg-[#FDFDFC] dark:bg-[#0a0a0a] text-[#1b1b18] dark:text-[#EDEDEC] flex flex-col min-h-screen p-6 lg:p-8">

    <header class="w-full max-w-6xl mx-auto mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold tracking-tight">CHED Visitor Management</h1>
            <p class="text-sm text-[#706f6c] dark:text-[#A1A09A] mt-1">Track and manage visitor records efficiently.</p>
        </div>
    </header>

    <main class="w-full max-w-6xl mx-auto flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6">

        <?php if(session('success')): ?>
            <div class="col-span-1 lg:col-span-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200 px-4 py-3 rounded-md text-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Add New Visitor Form -->
        <div class="lg:col-span-1">
            <div class="bg-white dark:bg-[#161615] rounded-lg shadow-sm border border-[#e3e3e0] dark:border-[#3E3E3A] p-6 sticky top-6">
                <h2 class="text-lg font-semibold mb-4">Add New Visitor</h2>
                <form action="<?php echo e(route('visitors.store')); ?>" method="POST" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="name" class="block text-sm font-medium mb-1">Full Name</label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required
                            class="w-full px-3 py-2 bg-[#FDFDFC] dark:bg-[#0a0a0a] border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="position" class="block text-sm font-medium mb-1">Position / Purpose</label>
                        <input type="text" name="position" id="position" value="<?php echo e(old('position')); ?>" required
                            class="w-full px-3 py-2 bg-[#FDFDFC] dark:bg-[#0a0a0a] border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="address" class="block text-sm font-medium mb-1">Address</label>
                        <textarea name="address" id="address" rows="3" required
                            class="w-full px-3 py-2 bg-[#FDFDFC] dark:bg-[#0a0a0a] border border-[#e3e3e0] dark:border-[#3E3E3A] rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('address')); ?></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="w-full bg-[#1b1b18] dark:bg-[#eeeeec] text-white dark:text-[#1C1C1A] font-medium py-2 px-4 rounded-md hover:bg-black dark:hover:bg-white transition-colors text-sm">
                        Save Visitor
                    </button>
                </form>
            </div>
        </div>

        <!-- Visitor List -->
        <div class="lg:col-span-2">
            <div class="bg-white dark:bg-[#161615] rounded-lg shadow-sm border border-[#e3e3e0] dark:border-[#3E3E3A] overflow-hidden">
                <div class="px-6 py-4 border-b border-[#e3e3e0] dark:border-[#3E3E3A] flex items-center justify-between">
                    <h2 class="text-lg font-semibold">Registered Visitors</h2>
                    <span class="text-xs font-medium px-2.5 py-0.5 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200">
                        <?php echo e($visitors->count()); ?> Total
                    </span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left">
                        <thead class="text-xs uppercase bg-gray-50 dark:bg-gray-800/50 text-[#706f6c] dark:text-[#A1A09A]">
                            <tr>
                                <th class="px-6 py-3 font-medium">Name</th>
                                <th class="px-6 py-3 font-medium">Position</th>
                                <th class="px-6 py-3 font-medium">Address</th>
                                <th class="px-6 py-3 font-medium text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-[#e3e3e0] dark:divide-[#3E3E3A]">
                            <?php $__empty_1 = true; $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                                    <td class="px-6 py-4 font-medium"><?php echo e($visitor->name); ?></td>
                                    <td class="px-6 py-4 text-[#706f6c] dark:text-[#A1A09A]"><?php echo e($visitor->position); ?></td>
                                    <td class="px-6 py-4 text-[#706f6c] dark:text-[#A1A09A] max-w-xs truncate" title="<?php echo e($visitor->address); ?>"><?php echo e($visitor->address); ?></td>
                                    <td class="px-6 py-4 text-right">
                                        <div class="flex items-center justify-end gap-3" x-data="{ open: false }">
                                            <form action="<?php echo e(route('visitors.update', $visitor->id)); ?>" method="POST" class="flex items-center gap-2" x-show="open" @click.outside="open = false">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <input type="text" name="name" value="<?php echo e($visitor->name); ?>" class="w-24 px-2 py-1 text-xs border rounded dark:bg-[#0a0a0a] dark:border-[#3E3E3A] focus:outline-none focus:ring-1 focus:ring-blue-500">
                                                <input type="text" name="position" value="<?php echo e($visitor->position); ?>" class="w-24 px-2 py-1 text-xs border rounded dark:bg-[#0a0a0a] dark:border-[#3E3E3A] focus:outline-none focus:ring-1 focus:ring-blue-500">
                                                <button type="submit" class="text-green-600 dark:text-green-400 hover:underline text-xs font-medium">Save</button>
                                                <button type="button" @click="open = false" class="text-gray-500 hover:underline text-xs">Cancel</button>
                                            </form>
                                            <div x-show="!open" class="flex items-center gap-3">
                                                <button type="button" @click="open = true" class="text-blue-600 dark:text-blue-400 hover:underline text-xs font-medium">Edit</button>
                                                <form action="<?php echo e(route('visitors.destroy', $visitor->id)); ?>" method="POST" onsubmit="return confirm('Delete this visitor?');" class="inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="text-red-600 dark:text-red-400 hover:underline text-xs font-medium">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="px-6 py-12 text-center text-[#706f6c] dark:text-[#A1A09A]">
                                        <p class="mb-2">No visitors found in the system.</p>
                                        <p class="text-xs">Use the form on the left to add your first visitor.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <footer class="w-full max-w-6xl mx-auto mt-8 pt-6 border-t border-[#e3e3e0] dark:border-[#3E3E3A] text-center text-xs text-[#706f6c] dark:text-[#A1A09A]">
        <p>&copy; <?php echo e(date('Y')); ?> CHED Visitor Management System. Built with Laravel <?php echo e(app()->version()); ?>.</p>
    </footer>

    <script>
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.documentElement.classList.add('dark');
        }
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
            if (event.matches) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        });
    </script>
</body>
</html><?php /**PATH C:\Users\itsme\VisitorChed\resources\views/visitors/index.blade.php ENDPATH**/ ?>